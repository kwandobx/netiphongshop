export type Notice = ['error' | 'updated', string]
