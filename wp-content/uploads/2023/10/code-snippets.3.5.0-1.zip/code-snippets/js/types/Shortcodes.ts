export interface SourceShortcodeAtts {
	id: string
	line_numbers: boolean
}

export interface ContentShortcodeAtts {
	id: string
	php: boolean
	format: boolean
	shortcodes: boolean
}
